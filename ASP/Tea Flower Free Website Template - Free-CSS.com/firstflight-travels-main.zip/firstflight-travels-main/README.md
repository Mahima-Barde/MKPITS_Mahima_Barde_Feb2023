<h2 align="center">Firstflight Travels</h2>
<div align="center">
<p>A travel website project created using HTML, CSS and JavaScript.</p>
<a href="https://mohdrahil101.github.io/firstflight-travels/" target="_blank"><strong>➥ Live Demo</strong></a>
</div> <br/><br/>
<b>Screenshots:</b> <br/><br/>
<img src="https://github.com/mohdrahil101/firstflight-travels/blob/main/readme%20images/readme-image.jpg"></img>
